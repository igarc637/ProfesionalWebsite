document.getElementById("back").addEventListener("click", function () {
  window.location.href = "homepage.html";
});
document.getElementById("p3").addEventListener("click", function () {
  window.location.href = "homepage.html";
});
