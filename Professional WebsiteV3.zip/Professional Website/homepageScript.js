let btnHover = document.getElementById("btnHover");

document.getElementById("edu").addEventListener("click", function () {
  window.location.href = "education.html";
});
document.getElementById("overview").addEventListener("click", function () {
  window.location.href = "overview.html";
});
document.getElementById("hobbies").addEventListener("click", function () {
  window.location.href = "hobbies.html";
});
document.getElementById("contact").addEventListener("click", function () {
  window.location.href = "contactInfo.html";
});

document.getElementById("edu").addEventListener("mouseover", function (e) {
  btnHover.style.display = "block";
  btnHover.style.marginTop = 286 + "px";
});
document.getElementById("contact").addEventListener("mouseover", function (e) {
  btnHover.style.display = "block";
  btnHover.style.marginTop = 382 + "px";
});
document.getElementById("overview").addEventListener("mouseover", function (e) {
  btnHover.style.display = "block";
  btnHover.style.marginTop = 477 + "px";
});
document.getElementById("hobbies").addEventListener("mouseover", function (e) {
  btnHover.style.display = "block";
  btnHover.style.marginTop = 573 + "px";
});
document.getElementById("edu").addEventListener("mouseout", function (e) {
  btnHover.style.display = "none";
});
document.getElementById("contact").addEventListener("mouseout", function (e) {
  btnHover.style.display = "none";
});
document.getElementById("overview").addEventListener("mouseout", function (e) {
  btnHover.style.display = "none";
});
document.getElementById("hobbies").addEventListener("mouseout", function (e) {
  btnHover.style.display = "none";
});

emailjs.init("StHM7xG8YqPTS9PSt");

function sendEmail() {
  const serviceID = "service_4spwg2l";
  const templateID = "template_5yzvkv7";
  const templateID2 = "template_ubakyq6";
  const params = {
    to_email: document.getElementById("email").value,
    to_name:
      document.getElementById("fname").value +
      " " +
      document.getElementById("lname").value,
    message:
      "This was there message:\n" + document.getElementById("message").value,
    my_email: "isaac@garciafab4.com",
  };
  if (
    document.getElementById("email").value != "" &&
    document.getElementById("fname").value != "" &&
    document.getElementById("lname").value != "" &&
    document.getElementById("message").value != ""
  ) {
    emailjs.send(serviceID, templateID, params).then(
      function (response) {
        console.log("Email sent:", response);
      },
      function (error) {
        console.log("Error sending email:", error);
      }
    );

    emailjs.send(serviceID, templateID2, params).then(
      function (response) {
        console.log("Email sent:", response);
      },
      function (error) {
        console.log("Error sending email:", error);
      }
    );
    document.getElementById("err").style.display = "none";
    document.getElementById("fname").style.borderColor = "rgb(119,141,169)";
    document.getElementById("lname").style.borderColor = "rgb(119,141,169)";
    document.getElementById("email").style.borderColor = "rgb(119,141,169)";
    document.getElementById("message").style.borderColor = "rgb(119,141,169)";
  } else if (
    (document.getElementById("email").value == "" &&
      document.getElementById("fname").value == "" &&
      document.getElementById("lname").value == "" &&
      document.getElementById("message").value == "") ||
    document.getElementById("email").value == "" ||
    document.getElementById("email").value == " " ||
    document.getElementById("fname").value == "" ||
    document.getElementById("fname").value == " " ||
    document.getElementById("lname").value == "" ||
    document.getElementById("lname").value == " " ||
    document.getElementById("message").value == "" ||
    document.getElementById("message").value == " "
  ) {
    document.getElementById("err").style.display = "block";
    document.getElementById("fname").style.borderColor = "rgb(221, 33, 33)";
    document.getElementById("lname").style.borderColor = "rgb(221, 33, 33)";
    document.getElementById("email").style.borderColor = "rgb(221, 33, 33)";
    document.getElementById("message").style.borderColor = "rgb(221, 33, 33)";
  }
}
