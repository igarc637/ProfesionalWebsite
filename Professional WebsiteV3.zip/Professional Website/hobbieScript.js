document.getElementById("back").addEventListener("click", function () {
  window.location.href = "homepage.html";
});
let codingFocus = false;
let mtbFocus = false;
let vidGFocus = false;

document.getElementById("coding").addEventListener("click", function () {
  codingFocus = true;
  window.scrollTo(0, 250);
});
document.getElementById("mtb").addEventListener("click", function () {
  window.scrollTo(0, 1080);
  mtbFocus = true;
});
document.getElementById("vidG").addEventListener("click", function () {
  window.scrollTo(0, 1900);
  vidGFocus = true;
});
document.addEventListener("scroll", function () {
  if (window.scrollY != 250) {
    codingFocus = false;
  }
  if (window.scrollY != 1080) {
    mtbFocus = false;
  }
  if (window.scrollY != 1900) {
    vidGFocus = false;
  }
});
const gameStart = function () {
  requestAnimationFrame(gameStart);

  if (codingFocus) {
    document.getElementById("coding").style.borderColor = "green";
  } else {
    document.getElementById("coding").style.borderColor = "rgb(119, 141, 169)";
  }
  if (mtbFocus) {
    document.getElementById("mtb").style.borderColor = "green";
  } else {
    document.getElementById("mtb").style.borderColor = "rgb(119, 141, 169)";
  }
  if (vidGFocus) {
    document.getElementById("vidG").style.borderColor = "green";
  } else {
    document.getElementById("vidG").style.borderColor = "rgb(119, 141, 169)";
  }
};
gameStart();
