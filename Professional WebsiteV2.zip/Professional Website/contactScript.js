document.getElementById("back").addEventListener("click", function () {
  window.location.href = "homepage.html";
});
document.getElementById("linkedinImg").addEventListener("click", function () {
  window.open("https://www.linkedin.com/in/isaac-garcia-658291274/", "_blank");
});
document.getElementById("githubImg").addEventListener("click", function () {
  window.open("https://github.com/igarc637", "_blank");
});
